// ========================
// FOODUZJPN MAIN APPLICATION
// ========================

class FoodUzJpn {
    constructor() {
        this.currentLang = 'uz';
        this.cart = [];
        this.products = [];
        this.translations = {};
        
        this.init();
    }

    // ========================
    // INITIALIZATION
    // ========================
    async init() {
        // Hide loading screen
        this.hideLoading();
        
        // Load translations
        await this.loadTranslations();
        
        // Load products
        await this.loadProducts();
        
        // Initialize components
        this.initLanguageSwitcher();
        this.initNavigation();
        this.initCart();
        this.initProductFilters();
        this.initContactForm();
        this.initScrollEffects();
        this.initAnimations();
        
        // Set initial language
        this.setLanguage(this.currentLang);
        
        console.log('🍱 FoodUzJpn initialized successfully!');
    }

    // ========================
    // LOADING SCREEN
    // ========================
    hideLoading() {
        const loadingScreen = document.getElementById('loading');
        if (loadingScreen) {
            setTimeout(() => {
                loadingScreen.classList.add('hidden');
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                }, 500);
            }, 1000);
        }
    }

    // ========================
    // TRANSLATIONS SYSTEM
    // ========================
    async loadTranslations() {
        this.translations = {
            'uz': {
                // Navigation
                'home': 'Bosh Sahifa',
                'about': 'Biz Haqimizda',
                'menu': 'Menu',
                'contact': 'Bog\'lanish',
                'cart': 'Savat',
                
                // Hero Section
                'hero-title': 'O\'zbekiston va Yaponiyaning Eng Mazali Taomlari',
                'hero-subtitle': 'Biz sizga an\'anaviy o\'zbek oshidan tortib, original yapon sushi va ramenlarigacha bo\'lgan mazali taomlarni tez va xavfsiz yetkazib beramiz',
                'happy-customers': 'Mamnun Mijozlar',
                'dishes': 'Turli Taomlar',
                'minutes': 'Daqiqa Yetkazish',
                'order-now': 'Hozir Buyurtma Berish',
                'learn-more': 'Biz Haqimizda',
                
                // Features
                'why-choose-us': 'Nega Bizni Tanlashadi?',
                'features-subtitle': 'Bizning afzalliklarimiz',
                'fast-delivery': 'Tez Yetkazish',
                'fast-delivery-desc': '30 daqiqa ichida bepul yetkazib berish',
                'quality': 'Yuqori Sifat',
                'quality-desc': 'Faqat eng yangi va sifatli mahsulotlar',
                'affordable': 'Hamyonbop Narxlar',
                'affordable-desc': 'Hammoning hamyoniga mos narxlar',
                'promotions': 'Doimiy Aksiyalar',
                'promotions-desc': 'Yangi mijozlar uchun maxsus chegirmalar',
                
                // Menu
                'our-menu': 'Bizning Menu',
                'menu-subtitle': 'Eng mashhur taomlarimiz',
                'all': 'Hammasi',
                'uzbek': 'O\'zbek Taomlari',
                'japanese': 'Yapon Taomlari',
                'drinks': 'Ichimliklar',
                'add-to-cart': 'Savatga Qo\'shish',
                
                // About
                'about-title': 'FoodUzJpn Haqida',
                'about-desc': '2024-yilda asos solingan FoodUzJpn - bu O\'zbekiston va Yaponiya oshxonalarining eng yaxshi an\'analarini birlashtirgan innovatsion food delivery xizmati.',
                'fresh-ingredients': 'Kunlik yangi ingredientlar',
                'professional-chefs': 'Professional oshpazlar',
                'hygiene': 'Yuqori gigiyena standartlari',
                
                // Contact
                'contact-us': 'Bog\'laning',
                'contact-subtitle': 'Savollaringiz bormi? Bizga yozing',
                'call-us': 'Qo\'ng\'iroq Qiling',
                'telegram': 'Telegram',
                'email': 'Email',
                'address': 'Manzil',
                'address-desc': 'Toshkent shahar, Yunusobod tumani',
                'name-placeholder': 'Ismingiz',
                'phone-placeholder': 'Telefon raqamingiz',
                'message-placeholder': 'Xabaringiz...',
                'send-message': 'Xabar Yuborish',
                
                // Cart & Orders
                'your-cart': 'Sizning Savatingiz',
                'total': 'Jami',
                'continue-shopping': 'Xaridni Davom Ettirish',
                'checkout': 'Buyurtma Berish',
                'remove': 'O\'chirish',
                'quantity': 'Miqdor',
                'empty-cart': 'Savat bo\'sh',
                
                // Footer
                'footer-desc': 'O\'zbekiston va Yaponiya taomlarining eng yaxshi uyushmasi',
                'quick-links': 'Tez Havolalar',
                'contact-info': 'Aloqa Ma\'lumotlari',
                'working-hours': 'Ish Soatlari',
                'everyday': 'Har kuni: 09:00 - 23:00',
                'delivery-hours': 'Yetkazish: 24/7',
                'all-rights-reserved': 'Barcha huquqlar himoyalangan'
            },
            'ru': {
                // Navigation
                'home': 'Главная',
                'about': 'О Нас',
                'menu': 'Меню',
                'contact': 'Контакты',
                'cart': 'Корзина',
                
                // Hero Section
                'hero-title': 'Лучшие блюда Узбекистана и Японии',
                'hero-subtitle': 'Мы доставляем вкусные блюда от традиционного узбекского плова до оригинальных японских суши и раменов быстро и безопасно',
                'happy-customers': 'Довольные клиенты',
                'dishes': 'Различные блюда',
                'minutes': 'Минут доставка',
                'order-now': 'Заказать Сейчас',
                'learn-more': 'Узнать Больше',
                
                // Features
                'why-choose-us': 'Почему выбирают нас?',
                'features-subtitle': 'Наши преимущества',
                'fast-delivery': 'Быстрая доставка',
                'fast-delivery-desc': 'Бесплатная доставка в течение 30 минут',
                'quality': 'Высокое качество',
                'quality-desc': 'Только самые свежие и качественные продукты',
                'affordable': 'Доступные цены',
                'affordable-desc': 'Цены по карману каждому',
                'promotions': 'Постоянные акции',
                'promotions-desc': 'Специальные скидки для новых клиентов',
                
                // Menu
                'our-menu': 'Наше Меню',
                'menu-subtitle': 'Наши самые популярные блюда',
                'all': 'Все',
                'uzbek': 'Узбекские блюда',
                'japanese': 'Японские блюда',
                'drinks': 'Напитки',
                'add-to-cart': 'В Корзину',
                
                // About
                'about-title': 'О FoodUzJpn',
                'about-desc': 'Основанный в 2024 году, FoodUzJpn - это инновационный сервис доставки еды, объединяющий лучшие традиции узбекской и японской кухонь.',
                'fresh-ingredients': 'Ежедневно свежие ингредиенты',
                'professional-chefs': 'Профессиональные повара',
                'hygiene': 'Высокие стандарты гигиены',
                
                // Contact
                'contact-us': 'Свяжитесь с нами',
                'contact-subtitle': 'Есть вопросы? Напишите нам',
                'call-us': 'Позвоните нам',
                'telegram': 'Телеграм',
                'email': 'Email',
                'address': 'Адрес',
                'address-desc': 'г. Ташкент, Юнусабадский район',
                'name-placeholder': 'Ваше имя',
                'phone-placeholder': 'Ваш номер телефона',
                'message-placeholder': 'Ваше сообщение...',
                'send-message': 'Отправить сообщение',
                
                // Cart & Orders
                'your-cart': 'Ваша Корзина',
                'total': 'Итого',
                'continue-shopping': 'Продолжить покупки',
                'checkout': 'Оформить заказ',
                'remove': 'Удалить',
                'quantity': 'Количество',
                'empty-cart': 'Корзина пуста',
                
                // Footer
                'footer-desc': 'Лучшее сочетание узбекской и японской кухонь',
                'quick-links': 'Быстрые ссылки',
                'contact-info': 'Контактная информация',
                'working-hours': 'Часы работы',
                'everyday': 'Ежедневно: 09:00 - 23:00',
                'delivery-hours': 'Доставка: 24/7',
                'all-rights-reserved': 'Все права защищены'
            },
            'en': {
                // Navigation
                'home': 'Home',
                'about': 'About',
                'menu': 'Menu',
                'contact': 'Contact',
                'cart': 'Cart',
                
                // Hero Section
                'hero-title': 'The Best Uzbek & Japanese Cuisine',
                'hero-subtitle': 'We deliver delicious dishes from traditional Uzbek plov to original Japanese sushi and ramen quickly and safely',
                'happy-customers': 'Happy Customers',
                'dishes': 'Various Dishes',
                'minutes': 'Minute Delivery',
                'order-now': 'Order Now',
                'learn-more': 'Learn More',
                
                // Features
                'why-choose-us': 'Why Choose Us?',
                'features-subtitle': 'Our advantages',
                'fast-delivery': 'Fast Delivery',
                'fast-delivery-desc': 'Free delivery within 30 minutes',
                'quality': 'High Quality',
                'quality-desc': 'Only the freshest and highest quality products',
                'affordable': 'Affordable Prices',
                'affordable-desc': 'Prices suitable for everyone\'s budget',
                'promotions': 'Regular Promotions',
                'promotions-desc': 'Special discounts for new customers',
                
                // Menu
                'our-menu': 'Our Menu',
                'menu-subtitle': 'Our most popular dishes',
                'all': 'All',
                'uzbek': 'Uzbek Dishes',
                'japanese': 'Japanese Dishes',
                'drinks': 'Drinks',
                'add-to-cart': 'Add to Cart',
                
                // About
                'about-title': 'About FoodUzJpn',
                'about-desc': 'Founded in 2024, FoodUzJpn is an innovative food delivery service that combines the best traditions of Uzbek and Japanese cuisines.',
                'fresh-ingredients': 'Daily fresh ingredients',
                'professional-chefs': 'Professional chefs',
                'hygiene': 'High hygiene standards',
                
                // Contact
                'contact-us': 'Contact Us',
                'contact-subtitle': 'Have questions? Write to us',
                'call-us': 'Call Us',
                'telegram': 'Telegram',
                'email': 'Email',
                'address': 'Address',
                'address-desc': 'Tashkent city, Yunusabad district',
                'name-placeholder': 'Your name',
                'phone-placeholder': 'Your phone number',
                'message-placeholder': 'Your message...',
                'send-message': 'Send Message',
                
                // Cart & Orders
                'your-cart': 'Your Cart',
                'total': 'Total',
                'continue-shopping': 'Continue Shopping',
                'checkout': 'Checkout',
                'remove': 'Remove',
                'quantity': 'Quantity',
                'empty-cart': 'Cart is empty',
                
                // Footer
                'footer-desc': 'The best combination of Uzbek and Japanese cuisines',
                'quick-links': 'Quick Links',
                'contact-info': 'Contact Information',
                'working-hours': 'Working Hours',
                'everyday': 'Everyday: 09:00 - 23:00',
                'delivery-hours': 'Delivery: 24/7',
                'all-rights-reserved': 'All rights reserved'
            },
            'ja': {
                // Navigation
                'home': 'ホーム',
                'about': 'About',
                'menu': 'メニュー',
                'contact': 'お問い合わせ',
                'cart': 'カート',
                
                // Hero Section
                'hero-title': 'ウズベキスタンと日本の最高の料理',
                'hero-subtitle': '伝統的なウズベクのプロフから本格的な日本の寿司、ラーメンまで、迅速かつ安全にお届けします',
                'happy-customers': '満足した顧客',
                'dishes': '様々な料理',
                'minutes': '分配達',
                'order-now': '今すぐ注文',
                'learn-more': '詳細を見る',
                
                // Features
                'why-choose-us': 'なぜ私たちを選ぶのか',
                'features-subtitle': '私たちの利点',
                'fast-delivery': '迅速な配達',
                'fast-delivery-desc': '30分以内の無料配達',
                'quality': '高品質',
                'quality-desc': '最高に新鮮で質の高い製品のみ',
                'affordable': '手頃な価格',
                'affordable-desc': '誰にでも適した価格',
                'promotions': '定期的なプロモーション',
                'promotions-desc': '新規顧客への特別割引',
                
                // Menu
                'our-menu': '私たちのメニュー',
                'menu-subtitle': '人気の料理',
                'all': 'すべて',
                'uzbek': 'ウズベク料理',
                'japanese': '日本料理',
                'drinks': 'ドリンク',
                'add-to-cart': 'カートに追加',
                
                // About
                'about-title': 'FoodUzJpnについて',
                'about-desc': '2024年に設立されたFoodUzJpnは、ウズベクと日本の料理の最高の伝統を組み合わせた革新的なフードデリバリーサービスです。',
                'fresh-ingredients': '毎日新鮮な食材',
                'professional-chefs': 'プロのシェフ',
                'hygiene': '高い衛生基準',
                
                // Contact
                'contact-us': 'お問い合わせ',
                'contact-subtitle': '質問がありますか？お書きください',
                'call-us': 'お電話ください',
                'telegram': 'テレグラム',
                'email': 'メール',
                'address': '住所',
                'address-desc': 'タシケント市、ユヌサバド地区',
                'name-placeholder': 'お名前',
                'phone-placeholder': '電話番号',
                'message-placeholder': 'メッセージ...',
                'send-message': 'メッセージを送信',
                
                // Cart & Orders
                'your-cart': 'カート',
                'total': '合計',
                'continue-shopping': '買い物を続ける',
                'checkout': '注文する',
                'remove': '削除',
                'quantity': '数量',
                'empty-cart': 'カートは空です',
                
                // Footer
                'footer-desc': 'ウズベクと日本料理の最高の組み合わせ',
                'quick-links': 'クイックリンク',
                'contact-info': '連絡先情報',
                'working-hours': '営業時間',
                'everyday': '毎日: 09:00 - 23:00',
                'delivery-hours': '配達: 24/7',
                'all-rights-reserved': '全著作権所有'
            }
        };
    }

    setLanguage(lang) {
        if (!this.translations[lang]) return;
        
        this.currentLang = lang;
        localStorage.setItem('fooduzjpn_lang', lang);
        
        // Update all translatable elements
        document.querySelectorAll('[data-translate]').forEach(element => {
            const key = element.getAttribute('data-translate');
            const translation = this.translations[lang][key];
            
            if (translation) {
                if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                    element.placeholder = translation;
                } else {
                    element.textContent = translation;
                }
            }
        });
        
        // Update language switcher
        this.updateLanguageSwitcher(lang);
        
        // Update cart display
        this.updateCartDisplay();
    }

    updateLanguageSwitcher(lang) {
        const langBtn = document.getElementById('langBtn');
        const langCode = langBtn.querySelector('.lang-code');
        const flag = langBtn.querySelector('.flag');
        
        const flags = { 'uz': '🇺🇿', 'ru': '🇷🇺', 'en': '🇺🇸', 'ja': '🇯🇵' };
        const codes = { 'uz': 'UZ', 'ru': 'RU', 'en': 'EN', 'ja': 'JA' };
        
        if (flag) flag.textContent = flags[lang] || '🌐';
        if (langCode) langCode.textContent = codes[lang] || lang.toUpperCase();
    }

    // ========================
    // LANGUAGE SWITCHER
    // ========================
    initLanguageSwitcher() {
        const langBtn = document.getElementById('langBtn');
        const langDropdown = document.getElementById('langDropdown');
        const langOptions = document.querySelectorAll('.lang-option');
        
        if (langBtn) {
            langBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                langDropdown.classList.toggle('show');
            });
        }
        
        langOptions.forEach(option => {
            option.addEventListener('click', (e) => {
                e.preventDefault();
                const lang = option.getAttribute('data-lang');
                this.setLanguage(lang);
                langDropdown.classList.remove('show');
            });
        });
        
        // Close dropdown when clicking outside
        document.addEventListener('click', () => {
            langDropdown.classList.remove('show');
        });
        
        // Load saved language
        const savedLang = localStorage.getItem('fooduzjpn_lang') || 'uz';
        this.setLanguage(savedLang);
    }

    // ========================
    // PRODUCTS SYSTEM
    // ========================
    async loadProducts() {
        this.products = [
            {
                id: 1,
                name: 'Osh',
                name_uz: 'Osh',
                name_ru: 'Плов',
                name_en: 'Plov',
                name_ja: 'プロフ',
                category: 'uzbek',
                price: 45000,
                image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=400&h=300&fit=crop',
                description: 'An\'anaviy o\'zbek oshi',
                description_uz: 'An\'anaviy o\'zbek oshi',
                description_ru: 'Традиционный узбекский плов',
                description_en: 'Traditional Uzbek plov',
                description_ja: '伝統的なウズベクのプロフ',
                rating: 4.9,
                preparation_time: 25
            },
            {
                id: 2,
                name: 'Sushi',
                name_uz: 'Sushi',
                name_ru: 'Суши',
                name_en: 'Sushi',
                name_ja: '寿司',
                category: 'japanese',
                price: 65000,
                image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=400&h=300&fit=crop',
                description: 'Yaponiyaning an\'anaviy taomi',
                description_uz: 'Yaponiyaning an\'anaviy taomi',
                description_ru: 'Традиционное японское блюдо',
                description_en: 'Traditional Japanese dish',
                description_ja: '伝統的な日本料理',
                rating: 4.8,
                preparation_time: 15
            },
            {
                id: 3,
                name: 'Ramen',
                name_uz: 'Ramen',
                name_ru: 'Рамен',
                name_en: 'Ramen',
                name_ja: 'ラーメン',
                category: 'japanese',
                price: 55000,
                image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&h=300&fit=crop',
                description: 'Yapon lag\'moni',
                description_uz: 'Yapon lag\'moni',
                description_ru: 'Японская лапша',
                description_en: 'Japanese noodles',
                description_ja: '日本の麺料理',
                rating: 4.7,
                preparation_time: 20
            },
            {
                id: 4,
                name: 'Qazi',
                name_uz: 'Qazi',
                name_ru: 'Казы',
                name_en: 'Qazi',
                name_ja: 'カジ',
                category: 'uzbek',
                price: 70000,
                image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop',
                description: 'An\'anaviy o\'zbek qazi',
                description_uz: 'An\'anaviy o\'zbek qazi',
                description_ru: 'Традиционная узбекская казы',
                description_en: 'Traditional Uzbek qazi',
                description_ja: '伝統的なウズベクのカジ',
                rating: 4.6,
                preparation_time: 30
            },
            {
                id: 5,
                name: 'Manti',
                name_uz: 'Manti',
                name_ru: 'Манты',
                name_en: 'Manti',
                name_ja: 'マンティ',
                category: 'uzbek',
                price: 35000,
                image: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?w=400&h=300&fit=crop',
                description: 'Go\'shtli manti',
                description_uz: 'Go\'shtli manti',
                description_ru: 'Манты с мясом',
                description_en: 'Meat manti',
                description_ja: '肉まん',
                rating: 4.5,
                preparation_time: 18
            },
            {
                id: 6,
                name: 'Tempura',
                name_uz: 'Tempura',
                name_ru: 'Темпура',
                name_en: 'Tempura',
                name_ja: '天ぷら',
                category: 'japanese',
                price: 48000,
                image: 'https://images.unsplash.com/photo-1563379091339-03246963d9fb?w=400&h=300&fit=crop',
                description: 'Qiovurlangan dengiz mahsulotlari',
                description_uz: 'Qiovurlangan dengiz mahsulotlari',
                description_ru: 'Жареные морепродукты',
                description_en: 'Fried seafood',
                description_ja: '揚げたシーフード',
                rating: 4.4,
                preparation_time: 12
            },
            {
                id: 7,
                name: 'Coca-Cola',
                name_uz: 'Coca-Cola',
                name_ru: 'Кока-Кола',
                name_en: 'Coca-Cola',
                name_ja: 'コカ・コーラ',
                category: 'drinks',
                price: 12000,
                image: 'https://images.unsplash.com/photo-1554866585-cd94860890b7?w=400&h=300&fit=crop',
                description: '0.5L',
                rating: 4.3,
                preparation_time: 2
            },
            {
                id: 8,
                name: 'Green Tea',
                name_uz: 'Yashil Choy',
                name_ru: 'Зеленый Чай',
                name_en: 'Green Tea',
                name_ja: '緑茶',
                category: 'drinks',
                price: 8000,
                image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400&h=300&fit=crop',
                description: 'Yapon yashil choyi',
                description_uz: 'Yapon yashil choyi',
                description_ru: 'Японский зеленый чай',
                description_en: 'Japanese green tea',
                description_ja: '日本の緑茶',
                rating: 4.2,
                preparation_time: 5
            }
        ];
        
        this.renderProducts();
    }

    renderProducts(category = 'all') {
        const productsGrid = document.getElementById('products-grid');
        if (!productsGrid) return;
        
        let filteredProducts = this.products;
        if (category !== 'all') {
            filteredProducts = this.products.filter(product => product.category === category);
        }
        
        productsGrid.innerHTML = filteredProducts.map(product => {
            const productName = product[`name_${this.currentLang}`] || product.name;
            const productDesc = product[`description_${this.currentLang}`] || product.description;
            
            return `
                <div class="product-card" data-category="${product.category}">
                    <div class="product-image">
                        <img src="${product.image}" alt="${productName}" loading="lazy">
                        <div class="product-badge">
                            <span class="rating">⭐ ${product.rating}</span>
                            <span class="time">⏱ ${product.preparation_time}min</span>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3>${productName}</h3>
                        <p class="product-description">${productDesc}</p>
                        <div class="product-price">${this.formatPrice(product.price)}</div>
                        <button class="btn btn-primary add-to-cart" 
                                data-product-id="${product.id}"
                                data-translate="add-to-cart">
                            <i class="fas fa-shopping-cart"></i>
                            ${this.translations[this.currentLang]['add-to-cart']}
                        </button>
                    </div>
                </div>
            `;
        }).join('');
        
        this.initAddToCartButtons();
    }

    // ========================
    // PRODUCT FILTERS
    // ========================
    initProductFilters() {
        const filterButtons = document.querySelectorAll('.filter-btn');
        
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                button.classList.add('active');
                
                // Filter products
                const category = button.getAttribute('data-category');
                this.renderProducts(category);
            });
        });
    }

    // ========================
    // CART SYSTEM
    // ========================
    initCart() {
        this.loadCartFromStorage();
        this.initCartModal();
        this.updateCartDisplay();
    }

    loadCartFromStorage() {
        const savedCart = localStorage.getItem('fooduzjpn_cart');
        if (savedCart) {
            this.cart = JSON.parse(savedCart);
        }
    }

    saveCartToStorage() {
        localStorage.setItem('fooduzjpn_cart', JSON.stringify(this.cart));
    }

    initAddToCartButtons() {
        const addToCartButtons = document.querySelectorAll('.add-to-cart');
        
        addToCartButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const productId = parseInt(button.getAttribute('data-product-id'));
                this.addToCart(productId);
            });
        });
    }

    addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) return;
        
        const existingItem = this.cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cart.push({
                ...product,
                quantity: 1,
                addedAt: new Date().toISOString()
            });
        }
        
        this.saveCartToStorage();
        this.updateCartDisplay();
        this.showAddToCartAnimation(product);
    }

    removeFromCart(productId) {
        this.cart = this.cart.filter(item => item.id !== productId);
        this.saveCartToStorage();
        this.updateCartDisplay();
        this.updateCartModal();
    }

    updateCartQuantity(productId, quantity) {
        const item = this.cart.find(item => item.id === productId);
        if (item) {
            if (quantity <= 0) {
                this.removeFromCart(productId);
            } else {
                item.quantity = quantity;
                this.saveCartToStorage();
                this.updateCartDisplay();
                this.updateCartModal();
            }
        }
    }

    getCartTotal() {
        return this.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    getCartItemCount() {
        return this.cart.reduce((count, item) => count + item.quantity, 0);
    }

    updateCartDisplay() {
        const cartCount = document.querySelector('.cart-count');
        const cartBtn = document.getElementById('cart-btn');
        
        const itemCount = this.getCartItemCount();
        
        if (cartCount) {
            cartCount.textContent = itemCount;
            cartCount.style.display = itemCount > 0 ? 'flex' : 'none';
        }
        
        if (cartBtn) {
            const cartText = this.translations[this.currentLang]?.['cart'] || 'Cart';
            cartBtn.innerHTML = `
                <i class="fas fa-shopping-cart"></i>
                <span data-translate="cart">${cartText}</span>
                <span class="cart-count">${itemCount}</span>
            `;
        }
    }

    // ========================
    // CART MODAL
    // ========================
    initCartModal() {
        const cartBtn = document.getElementById('cart-btn');
        const cartModal = document.getElementById('cartModal');
        const closeBtn = document.querySelector('.close');
        const continueShoppingBtn = document.getElementById('continue-shopping');
        const checkoutBtn = document.getElementById('checkout-btn');
        
        if (cartBtn) {
            cartBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.openCartModal();
            });
        }
        
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.closeCartModal();
            });
        }
        
        if (continueShoppingBtn) {
            continueShoppingBtn.addEventListener('click', () => {
                this.closeCartModal();
            });
        }
        
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', () => {
                this.checkout();
            });
        }
        
        // Close modal when clicking outside
        if (cartModal) {
            cartModal.addEventListener('click', (e) => {
                if (e.target === cartModal) {
                    this.closeCartModal();
                }
            });
        }
    }

    openCartModal() {
        const cartModal = document.getElementById('cartModal');
        if (cartModal) {
            this.updateCartModal();
            cartModal.classList.add('show');
            document.body.style.overflow = 'hidden';
        }
    }

    closeCartModal() {
        const cartModal = document.getElementById('cartModal');
        if (cartModal) {
            cartModal.classList.remove('show');
            document.body.style.overflow = '';
        }
    }

    updateCartModal() {
        const cartItems = document.getElementById('cart-items');
        const cartTotalPrice = document.getElementById('cart-total-price');
        
        if (!cartItems) return;
        
        if (this.cart.length === 0) {
            cartItems.innerHTML = `
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart"></i>
                    <p>${this.translations[this.currentLang]?.['empty-cart'] || 'Cart is empty'}</p>
                </div>
            `;
        } else {
            cartItems.innerHTML = this.cart.map(item => {
                const productName = item[`name_${this.currentLang}`] || item.name;
                
                return `
                    <div class="cart-item" data-product-id="${item.id}">
                        <img src="${item.image}" alt="${productName}">
                        <div class="cart-item-info">
                            <h4>${productName}</h4>
                            <div class="cart-item-price">${this.formatPrice(item.price)}</div>
                        </div>
                        <div class="cart-item-actions">
                            <button class="quantity-btn decrease">-</button>
                            <span class="quantity">${item.quantity}</span>
                            <button class="quantity-btn increase">+</button>
                            <button class="remove-btn" title="${this.translations[this.currentLang]?.['remove'] || 'Remove'}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
            
            // Add event listeners to cart item buttons
            this.initCartItemEvents();
        }
        
        if (cartTotalPrice) {
            cartTotalPrice.textContent = this.formatPrice(this.getCartTotal());
        }
    }

    initCartItemEvents() {
        // Decrease quantity buttons
        document.querySelectorAll('.decrease').forEach(button => {
            button.addEventListener('click', (e) => {
                const productId = parseInt(e.target.closest('.cart-item').getAttribute('data-product-id'));
                const item = this.cart.find(item => item.id === productId);
                if (item) {
                    this.updateCartQuantity(productId, item.quantity - 1);
                }
            });
        });
        
        // Increase quantity buttons
        document.querySelectorAll('.increase').forEach(button => {
            button.addEventListener('click', (e) => {
                const productId = parseInt(e.target.closest('.cart-item').getAttribute('data-product-id'));
                const item = this.cart.find(item => item.id === productId);
                if (item) {
                    this.updateCartQuantity(productId, item.quantity + 1);
                }
            });
        });
        
        // Remove buttons
        document.querySelectorAll('.remove-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const productId = parseInt(e.target.closest('.cart-item').getAttribute('data-product-id'));
                this.removeFromCart(productId);
            });
        });
    }

    // ========================
    // CHECKOUT SYSTEM
    // ========================
    checkout() {
        if (this.cart.length === 0) {
            this.showNotification(this.translations[this.currentLang]?.['empty-cart'] || 'Cart is empty', 'warning');
            return;
        }
        
        const customerName = prompt(this.translations[this.currentLang]?.['name-placeholder'] || 'Your name:');
        const customerPhone = prompt(this.translations[this.currentLang]?.['phone-placeholder'] || 'Your phone number:');
        const customerAddress = prompt('Manzilingiz:' || 'Your address:');
        
        if (customerName && customerPhone && customerAddress) {
            this.processOrder(customerName, customerPhone, customerAddress);
        }
    }

    async processOrder(name, phone, address) {
        const order = {
            id: 'ORD_' + Date.now(),
            customer: { name, phone, address },
            items: this.cart,
            total: this.getCartTotal(),
            status: 'pending',
            timestamp: new Date().toISOString(),
            estimated_delivery: new Date(Date.now() + 30 * 60000).toISOString() // 30 minutes
        };
        
        // Save order to localStorage (in real app, this would go to a database)
        this.saveOrder(order);
        
        // Send notification (in real app, this would be Telegram/Email/SMS)
        await this.sendOrderNotification(order);
        
        // Clear cart
        this.cart = [];
        this.saveCartToStorage();
        this.updateCartDisplay();
        this.updateCartModal();
        this.closeCartModal();
        
        // Show success message
        this.showOrderSuccess(order);
    }

    saveOrder(order) {
        const orders = JSON.parse(localStorage.getItem('fooduzjpn_orders')) || [];
        orders.push(order);
        localStorage.setItem('fooduzjpn_orders', JSON.stringify(orders));
    }

    async sendOrderNotification(order) {
        // In a real application, this would send to Telegram, Email, or SMS
        console.log('Order notification:', order);
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // ========================
    // CONTACT FORM
    // ========================
    initContactForm() {
        const contactForm = document.getElementById('contactForm');
        if (contactForm) {
            contactForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleContactFormSubmit();
            });
        }
    }

    async handleContactFormSubmit() {
        const name = document.getElementById('name').value;
        const phone = document.getElementById('phone').value;
        const message = document.getElementById('message').value;
        
        if (!name || !phone || !message) {
            this.showNotification('Iltimos, barcha maydonlarni to\'ldiring', 'warning');
            return;
        }
        
        // Simulate form submission
        this.showNotification('Xabaringiz yuborilmoqda...', 'info');
        
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Show success message
        this.showNotification('Xabaringiz muvaffaqiyatli yuborildi! Tez orada siz bilan bog\'lanamiz.', 'success');
        
        // Reset form
        document.getElementById('contactForm').reset();
    }

    // ========================
    // NAVIGATION
    // ========================
    initNavigation() {
        this.initMobileMenu();
        this.initSmoothScroll();
        this.initActiveNavLinks();
    }

    initMobileMenu() {
        const hamburger = document.querySelector('.hamburger');
        const navMenu = document.querySelector('.nav-menu');
        
        if (hamburger && navMenu) {
            hamburger.addEventListener('click', () => {
                hamburger.classList.toggle('active');
                navMenu.classList.toggle('active');
            });
            
            // Close menu when clicking on links
            document.querySelectorAll('.nav-link').forEach(link => {
                link.addEventListener('click', () => {
                    hamburger.classList.remove('active');
                    navMenu.classList.remove('active');
                });
            });
        }
    }

    initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    }

    initActiveNavLinks() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-link');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const id = entry.target.getAttribute('id');
                    navLinks.forEach(link => {
                        link.classList.remove('active');
                        if (link.getAttribute('href') === `#${id}`) {
                            link.classList.add('active');
                        }
                    });
                }
            });
        }, {
            threshold: 0.5
        });
        
        sections.forEach(section => observer.observe(section));
    }

    // ========================
    // SCROLL EFFECTS
    // ========================
    initScrollEffects() {
        // Header scroll effect
        window.addEventListener('scroll', () => {
            const header = document.querySelector('.header');
            if (window.scrollY > 100) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
        
        // Parallax effect for hero section
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const parallax = document.querySelector('.hero');
            if (parallax) {
                parallax.style.transform = `translateY(${scrolled * 0.5}px)`;
            }
        });
    }

    // ========================
    // ANIMATIONS
    // ========================
    initAnimations() {
        // Intersection Observer for fade-in animations
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, {
            threshold: 0.1
        });
        
        // Observe elements for animation
        document.querySelectorAll('.feature-card, .product-card, .about-content, .contact-item').forEach(el => {
            observer.observe(el);
        });
    }

    showAddToCartAnimation(product) {
        // Create animation element
        const anim = document.createElement('div');
        anim.className = 'add-to-cart-animation';
        anim.innerHTML = '✓';
        anim.style.cssText = `
            position: fixed;
            background: var(--success-color);
            color: white;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            z-index: 10000;
            pointer-events: none;
            animation: cartAnimation 1s ease-in-out forwards;
        `;
        
        document.body.appendChild(anim);
        
        // Remove after animation
        setTimeout(() => {
            anim.remove();
        }, 1000);
    }

    showOrderSuccess(order) {
        this.showNotification(
            `🎉 Buyurtmangiz qabul qilindi! Yetkazib berish: 30 daqiqa. Buyurtma raqami: ${order.id}`,
            'success',
            5000
        );
    }

    showNotification(message, type = 'info', duration = 3000) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-icon">${this.getNotificationIcon(type)}</span>
                <span class="notification-message">${message}</span>
                <button class="notification-close">&times;</button>
            </div>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            padding: 1rem;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            z-index: 10000;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            max-width: 400px;
        `;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Close button
        notification.querySelector('.notification-close').addEventListener('click', () => {
            notification.remove();
        });
        
        // Auto remove
        if (duration > 0) {
            setTimeout(() => {
                notification.style.transform = 'translateX(400px)';
                setTimeout(() => notification.remove(), 300);
            }, duration);
        }
    }

    getNotificationIcon(type) {
        const icons = {
            'success': '✅',
            'error': '❌',
            'warning': '⚠️',
            'info': 'ℹ️'
        };
        return icons[type] || '💡';
    }

    // ========================
    // UTILITY FUNCTIONS
    // ========================
    formatPrice(amount) {
        return new Intl.NumberFormat('uz-UZ').format(amount) + ' so\'m';
    }

    // ========================
    // ADMIN PANEL ACCESS
    // ========================
    initAdminAccess() {
        // Add admin access shortcut (Ctrl+Alt+A)
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.altKey && e.key === 'a') {
                e.preventDefault();
                window.open('admin.html', '_blank');
            }
        });
    }
}

// ========================
// ADDITIONAL CSS FOR ANIMATIONS
// ========================
const additionalStyles = `
    @keyframes cartAnimation {
        0% {
            transform: scale(0) translateY(0);
            opacity: 0;
        }
        50% {
            transform: scale(1) translateY(-50px);
            opacity: 1;
        }
        100% {
            transform: scale(0) translateY(-100px);
            opacity: 0;
        }
    }
    
    .add-to-cart-animation {
        animation: cartAnimation 1s ease-in-out forwards;
    }
    
    .notification-success {
        border-left: 4px solid var(--success-color);
    }
    
    .notification-error {
        border-left: 4px solid var(--danger-color);
    }
    
    .notification-warning {
        border-left: 4px solid var(--warning-color);
    }
    
    .notification-info {
        border-left: 4px solid var(--secondary-color);
    }
    
    .notification-content {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .notification-close {
        background: none;
        border: none;
        font-size: 1.2rem;
        cursor: pointer;
        margin-left: auto;
    }
    
    .empty-cart {
        text-align: center;
        padding: 2rem;
        color: var(--text-light);
    }
    
    .empty-cart i {
        font-size: 3rem;
        margin-bottom: 1rem;
        opacity: 0.5;
    }
    
    .product-badge {
        position: absolute;
        top: 10px;
        right: 10px;
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    
    .product-badge span {
        background: rgba(0,0,0,0.7);
        color: white;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.8rem;
    }
    
    .product-image {
        position: relative;
    }
`;

// Add additional styles to document
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);

// ========================
// INITIALIZE APPLICATION
// ========================
document.addEventListener('DOMContentLoaded', () => {
    window.foodApp = new FoodUzJpn();
});

// Export for global access
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FoodUzJpn;
}