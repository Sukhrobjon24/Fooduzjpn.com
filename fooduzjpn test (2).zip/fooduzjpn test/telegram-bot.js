const botToken = '8425704819:AAEBFzWFM69MZsE9AbDZSVvH_-bdGWrYMYM';
const chatId = 'SIZNING_CHAT_ID'; // @userinfobot dan olishingiz mumkin