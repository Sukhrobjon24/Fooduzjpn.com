// ========================
// FOODUZJPN ADMIN PANEL
// ========================

class FoodUzJpnAdmin {
    constructor() {
        this.isAuthenticated = false;
        this.currentTab = 'dashboard';
        this.orders = [];
        this.products = [];
        this.customers = [];
        this.settings = {};
        this.charts = {};
        
        this.init();
    }

    // ========================
    // INITIALIZATION
    // ========================
    async init() {
        // Check authentication
        await this.checkAuthentication();
        
        // Load data
        await this.loadData();
        
        // Initialize components
        this.initEventListeners();
        this.initCharts();
        this.updateRealTimeStats();
        
        // Start real-time updates
        this.startRealTimeUpdates();
        
        console.log('👨‍💼 Admin Panel initialized successfully!');
    }

    // ========================
    // AUTHENTICATION SYSTEM
    // ========================
    async checkAuthentication() {
        const savedAuth = localStorage.getItem('fooduzjpn_admin_auth');
        
        if (savedAuth) {
            const authData = JSON.parse(savedAuth);
            if (authData.expires > Date.now()) {
                this.isAuthenticated = true;
                this.showAdminPanel();
                return;
            }
        }
        
        this.showLoginScreen();
    }

    showLoginScreen() {
        document.getElementById('loginScreen').style.display = 'flex';
        document.getElementById('adminPanel').style.display = 'none';
        this.initLoginForm();
    }

    showAdminPanel() {
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('adminPanel').style.display = 'flex';
        this.hideLoading();
        this.updateCurrentDate();
    }

    initLoginForm() {
        const loginForm = document.getElementById('loginForm');
        
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });
        
        // Demo credentials hint
        console.log('Demo credentials: admin / fooduzjpn2024');
    }

    async handleLogin() {
        const username = document.getElementById('adminUsername').value;
        const password = document.getElementById('adminPassword').value;
        
        // Demo authentication (in real app, this would be server-side)
        if (username === 'admin' && password === 'fooduzjpn2024') {
            // Save authentication
            const authData = {
                username: username,
                expires: Date.now() + (24 * 60 * 60 * 1000) // 24 hours
            };
            
            localStorage.setItem('fooduzjpn_admin_auth', JSON.stringify(authData));
            this.isAuthenticated = true;
            this.showAdminPanel();
            
            this.showNotification('Muvaffaqiyatli kirish!', 'success');
        } else {
            this.showNotification('Login yoki parol noto‘g‘ri!', 'error');
        }
    }

    handleLogout() {
        localStorage.removeItem('fooduzjpn_admin_auth');
        this.isAuthenticated = false;
        this.showLoginScreen();
        this.showNotification('Tizimdan chiqildi', 'info');
    }

    // ========================
    // DATA MANAGEMENT
    // ========================
    async loadData() {
        await this.loadOrders();
        await this.loadProducts();
        await this.loadCustomers();
        await this.loadSettings();
    }

    async loadOrders() {
        // Load from localStorage (in real app, this would be from API)
        const savedOrders = localStorage.getItem('fooduzjpn_orders');
        this.orders = savedOrders ? JSON.parse(savedOrders) : [];
        
        // Add some demo orders if empty
        if (this.orders.length === 0) {
            this.orders = this.generateDemoOrders();
            this.saveOrders();
        }
        
        this.updateOrdersDisplay();
    }

    async loadProducts() {
        // Load from main app or generate
        const savedProducts = localStorage.getItem('fooduzjpn_products');
        this.products = savedProducts ? JSON.parse(savedProducts) : [];
        
        if (this.products.length === 0) {
            this.products = this.generateDemoProducts();
            this.saveProducts();
        }
        
        this.updateProductsDisplay();
    }

    async loadCustomers() {
        // Extract customers from orders
        this.customers = this.extractCustomersFromOrders();
        this.updateCustomersDisplay();
    }

    async loadSettings() {
        const savedSettings = localStorage.getItem('fooduzjpn_admin_settings');
        this.settings = savedSettings ? JSON.parse(savedSettings) : this.getDefaultSettings();
        this.updateSettingsForm();
    }

    saveOrders() {
        localStorage.setItem('fooduzjpn_orders', JSON.stringify(this.orders));
    }

    saveProducts() {
        localStorage.setItem('fooduzjpn_products', JSON.stringify(this.products));
    }

    saveSettings() {
        localStorage.setItem('fooduzjpn_admin_settings', JSON.stringify(this.settings));
    }

    // ========================
    // DEMO DATA GENERATION
    // ========================
    generateDemoOrders() {
        const demoOrders = [];
        const statuses = ['pending', 'preparing', 'delivering', 'completed'];
        const products = this.generateDemoProducts();
        
        for (let i = 1; i <= 50; i++) {
            const orderDate = new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000);
            const itemCount = Math.floor(Math.random() * 3) + 1;
            const orderItems = [];
            
            let total = 0;
            for (let j = 0; j < itemCount; j++) {
                const product = products[Math.floor(Math.random() * products.length)];
                const quantity = Math.floor(Math.random() * 2) + 1;
                orderItems.push({
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    quantity: quantity
                });
                total += product.price * quantity;
            }
            
            demoOrders.push({
                id: 'ORD_' + (1000 + i),
                customer: {
                    name: this.generateRandomName(),
                    phone: '+9989' + Math.floor(Math.random() * 100000000).toString().padStart(8, '0'),
                    address: this.generateRandomAddress()
                },
                items: orderItems,
                total: total,
                status: statuses[Math.floor(Math.random() * statuses.length)],
                timestamp: orderDate.toISOString(),
                estimated_delivery: new Date(orderDate.getTime() + 30 * 60000).toISOString()
            });
        }
        
        return demoOrders;
    }

    generateDemoProducts() {
        return [
            {
                id: 1,
                name: 'Osh',
                category: 'uzbek',
                price: 45000,
                image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=400&h=300&fit=crop',
                description: 'An\'anaviy o\'zbek oshi',
                rating: 4.9,
                preparation_time: 25,
                ingredients: ['guruch', 'go\'sht', 'sabzi', 'piyoz'],
                is_available: true
            },
            {
                id: 2,
                name: 'Sushi',
                category: 'japanese',
                price: 65000,
                image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=400&h=300&fit=crop',
                description: 'Yaponiyaning an\'anaviy taomi',
                rating: 4.8,
                preparation_time: 15,
                ingredients: ['guruch', 'losos', 'avakado', 'nor'],
                is_available: true
            },
            // ... more products (same as main app)
        ];
    }

    generateRandomName() {
        const names = ['Ali Valiyev', 'Dilshod Xasanov', 'Nigora Qodirova', 'Shoxrux Yusupov', 
                      'Madina Tursunova', 'Javohir Rahimov', 'Sevinch Olimova', 'Behruz Karimov'];
        return names[Math.floor(Math.random() * names.length)];
    }

    generateRandomAddress() {
        const addresses = [
            'Toshkent, Yunusobod 5-mavze',
            'Toshkent, Chilonzor 12-massiv',
            'Toshkent, Mirzo Ulug\'bek 3-mavze',
            'Toshkent, Sergeli 7-mavze',
            'Toshkent, Yashnobod 4-mavze'
        ];
        return addresses[Math.floor(Math.random() * addresses.length)];
    }

    extractCustomersFromOrders() {
        const customerMap = new Map();
        
        this.orders.forEach(order => {
            const phone = order.customer.phone;
            if (!customerMap.has(phone)) {
                customerMap.set(phone, {
                    name: order.customer.name,
                    phone: phone,
                    address: order.customer.address,
                    order_count: 0,
                    total_spent: 0,
                    first_order: order.timestamp,
                    last_order: order.timestamp
                });
            }
            
            const customer = customerMap.get(phone);
            customer.order_count += 1;
            customer.total_spent += order.total;
            customer.last_order = order.timestamp;
        });
        
        return Array.from(customerMap.values());
    }

    getDefaultSettings() {
        return {
            restaurant_name: 'FoodUzJpn',
            restaurant_phone: '+998901234567',
            delivery_time: 30,
            min_order_amount: 25000,
            telegram_bot_token: '',
            telegram_chat_id: '',
            enable_telegram_notifications: false,
            enable_2fa: false,
            currency: 'so\'m',
            timezone: 'Asia/Tashkent'
        };
    }

    // ========================
    // EVENT LISTENERS
    // ========================
    initEventListeners() {
        // Navigation
        this.initNavigation();
        
        // Header actions
        this.initHeaderActions();
        
        // Orders management
        this.initOrdersManagement();
        
        // Products management
        this.initProductsManagement();
        
        // Settings
        this.initSettings();
        
        // Modals
        this.initModals();
    }

    initNavigation() {
        // Tab switching
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const tab = item.getAttribute('data-tab');
                this.switchTab(tab);
            });
        });
        
        // Sidebar toggle for mobile
        document.getElementById('sidebarToggle').addEventListener('click', () => {
            document.querySelector('.admin-sidebar').classList.toggle('active');
        });
        
        // Logout
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.handleLogout();
        });
    }

    initHeaderActions() {
        // Refresh button
        document.getElementById('refreshBtn').addEventListener('click', () => {
            this.refreshData();
        });
        
        // Fullscreen button
        document.getElementById('fullscreenBtn').addEventListener('click', () => {
            this.toggleFullscreen();
        });
        
        // Notifications button
        document.getElementById('notificationsBtn').addEventListener('click', () => {
            this.showNotificationsModal();
        });
    }

    initOrdersManagement() {
        // Search functionality
        document.getElementById('ordersSearch').addEventListener('input', (e) => {
            this.filterOrders(e.target.value);
        });
        
        // Status filter
        document.getElementById('ordersFilter').addEventListener('change', (e) => {
            this.filterOrdersByStatus(e.target.value);
        });
        
        // Export button
        document.getElementById('exportOrdersBtn').addEventListener('click', () => {
            this.exportOrdersToCSV();
        });
        
        // Pagination
        this.initPagination();
    }

    initProductsManagement() {
        // Add product button
        document.getElementById('addNewProductBtn').addEventListener('click', () => {
            this.showProductModal();
        });
        
        // Quick actions
        document.getElementById('addProductBtn').addEventListener('click', () => {
            this.showProductModal();
        });
    }

    initSettings() {
        // Save settings
        document.getElementById('saveSettingsBtn').addEventListener('click', () => {
            this.saveSettingsFromForm();
        });
        
        // Reset settings
        document.getElementById('resetSettingsBtn').addEventListener('click', () => {
            this.resetSettings();
        });
        
        // Data management buttons
        document.getElementById('exportDataBtn').addEventListener('click', () => {
            this.exportAllData();
        });
        
        document.getElementById('importDataBtn').addEventListener('click', () => {
            this.importData();
        });
        
        document.getElementById('clearDataBtn').addEventListener('click', () => {
            this.clearAllData();
        });
    }

    initModals() {
        // Close modals when clicking X
        document.querySelectorAll('.modal .close').forEach(closeBtn => {
            closeBtn.addEventListener('click', () => {
                this.closeAllModals();
            });
        });
        
        // Close modals when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeAllModals();
                }
            });
        });
        
        // Escape key to close modals
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    // ========================
    // TAB MANAGEMENT
    // ========================
    switchTab(tabName) {
        // Hide all tabs
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Remove active class from all nav items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // Show selected tab
        document.getElementById(tabName + 'Tab').classList.add('active');
        
        // Activate corresponding nav item
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        
        // Update page title
        this.updatePageTitle(tabName);
        
        // Update tab-specific content
        this.updateTabContent(tabName);
        
        this.currentTab = tabName;
    }

    updatePageTitle(tabName) {
        const titles = {
            'dashboard': 'Dashboard',
            'orders': 'Buyurtmalar',
            'products': 'Mahsulotlar',
            'customers': 'Mijozlar',
            'analytics': 'Analitika',
            'settings': 'Sozlamalar'
        };
        
        document.getElementById('pageTitle').textContent = titles[tabName] || 'Dashboard';
    }

    updateTabContent(tabName) {
        switch(tabName) {
            case 'dashboard':
                this.updateDashboard();
                break;
            case 'orders':
                this.updateOrdersTable();
                break;
            case 'products':
                this.updateProductsGrid();
                break;
            case 'customers':
                this.updateCustomersTable();
                break;
            case 'analytics':
                this.updateAnalyticsCharts();
                break;
        }
    }

    // ========================
    // DASHBOARD FUNCTIONALITY
    // ========================
    updateDashboard() {
        this.updateStatsCards();
        this.updateRecentActivity();
        this.updateCharts();
    }

    updateStatsCards() {
        const today = new Date().toDateString();
        const todayOrders = this.orders.filter(order => 
            new Date(order.timestamp).toDateString() === today
        );
        
        const todayRevenue = todayOrders.reduce((sum, order) => sum + order.total, 0);
        const newCustomersToday = this.customers.filter(customer =>
            new Date(customer.first_order).toDateString() === today
        ).length;
        
        // Update DOM elements
        document.getElementById('todayRevenue').textContent = this.formatPrice(todayRevenue);
        document.getElementById('todayOrders').textContent = todayOrders.length;
        document.getElementById('newCustomers').textContent = newCustomersToday;
        
        // Calculate changes (demo data)
        const revenueChange = todayRevenue > 0 ? 12 : 0;
        const ordersChange = todayOrders.length > 0 ? 8 : 0;
        const customersChange = newCustomersToday > 0 ? 5 : 0;
        
        document.getElementById('revenueChange').innerHTML = 
            `<i class="fas fa-arrow-up"></i> ${revenueChange}% o'sish`;
        document.getElementById('ordersChange').innerHTML = 
            `<i class="fas fa-arrow-up"></i> ${ordersChange}% o'sish`;
        document.getElementById('customersChange').innerHTML = 
            `<i class="fas fa-arrow-up"></i> ${customersChange}% o'sish`;
    }

    updateRecentActivity() {
        const activityList = document.getElementById('recentActivity');
        const recentOrders = this.orders
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
            .slice(0, 5);
        
        activityList.innerHTML = recentOrders.map(order => `
            <div class="activity-item">
                <div class="activity-icon order">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="activity-content">
                    <div class="activity-title">Yangi buyurtma #${order.id.slice(-4)}</div>
                    <div class="activity-desc">${order.customer.name} - ${this.formatPrice(order.total)}</div>
                    <div class="activity-time">${this.formatTimeAgo(order.timestamp)}</div>
                </div>
            </div>
        `).join('');
    }

    // ========================
    // ORDERS MANAGEMENT
    // ========================
    updateOrdersDisplay() {
        this.updateOrdersTable();
        this.updatePendingOrdersCount();
    }

    updateOrdersTable(filteredOrders = null) {
        const ordersToShow = filteredOrders || this.orders;
        const tbody = document.getElementById('ordersTableBody');
        
        if (ordersToShow.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center">Buyurtmalar topilmadi</td>
                </tr>
            `;
            return;
        }
        
        tbody.innerHTML = ordersToShow.map(order => `
            <tr>
                <td><strong>${order.id}</strong></td>
                <td>
                    <div>${order.customer.name}</div>
                    <small class="text-muted">${order.customer.phone}</small>
                </td>
                <td>
                    ${order.items.map(item => 
                        `${item.name} × ${item.quantity}`
                    ).join('<br>')}
                </td>
                <td>${this.formatPrice(order.total)}</td>
                <td>
                    <span class="status-badge status-${order.status}">
                        ${this.getStatusText(order.status)}
                    </span>
                </td>
                <td>${this.formatDateTime(order.timestamp)}</td>
                <td>
                    <div class="table-actions">
                        <button class="action-btn-small btn-view" onclick="admin.viewOrderDetails('${order.id}')">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn-small btn-edit" onclick="admin.editOrderStatus('${order.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn-small btn-delete" onclick="admin.deleteOrder('${order.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
        
        document.getElementById('showingOrders').textContent = ordersToShow.length;
    }

    filterOrders(searchTerm) {
        const filtered = this.orders.filter(order =>
            order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
            order.customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            order.customer.phone.includes(searchTerm)
        );
        this.updateOrdersTable(filtered);
    }

    filterOrdersByStatus(status) {
        const filtered = status === 'all' 
            ? this.orders 
            : this.orders.filter(order => order.status === status);
        this.updateOrdersTable(filtered);
    }

    updatePendingOrdersCount() {
        const pendingCount = this.orders.filter(order => order.status === 'pending').length;
        document.getElementById('pendingOrdersCount').textContent = pendingCount;
    }

    viewOrderDetails(orderId) {
        const order = this.orders.find(o => o.id === orderId);
        if (!order) return;
        
        const modalContent = document.getElementById('orderDetailsContent');
        modalContent.innerHTML = `
            <div class="order-details">
                <div class="detail-section">
                    <h4>Buyurtma Ma'lumotlari</h4>
                    <p><strong>ID:</strong> ${order.id}</p>
                    <p><strong>Holat:</strong> <span class="status-badge status-${order.status}">${this.getStatusText(order.status)}</span></p>
                    <p><strong>Sana:</strong> ${this.formatDateTime(order.timestamp)}</p>
                    <p><strong>Yetkazish:</strong> ${this.formatDateTime(order.estimated_delivery)}</p>
                </div>
                
                <div class="detail-section">
                    <h4>Mijoz Ma'lumotlari</h4>
                    <p><strong>Ism:</strong> ${order.customer.name}</p>
                    <p><strong>Telefon:</strong> ${order.customer.phone}</p>
                    <p><strong>Manzil:</strong> ${order.customer.address}</p>
                </div>
                
                <div class="detail-section">
                    <h4>Mahsulotlar</h4>
                    ${order.items.map(item => `
                        <div class="order-item-detail">
                            <span>${item.name} × ${item.quantity}</span>
                            <span>${this.formatPrice(item.price * item.quantity)}</span>
                        </div>
                    `).join('')}
                    <div class="order-total">
                        <strong>Jami: ${this.formatPrice(order.total)}</strong>
                    </div>
                </div>
                
                <div class="detail-actions">
                    <button class="btn btn-primary" onclick="admin.changeOrderStatus('${order.id}', 'preparing')">
                        Tayyorlashni Boshlash
                    </button>
                    <button class="btn btn-secondary" onclick="admin.printOrder('${order.id}')">
                        <i class="fas fa-print"></i> Chop etish
                    </button>
                </div>
            </div>
        `;
        
        this.showModal('orderDetailsModal');
    }

    changeOrderStatus(orderId, newStatus) {
        const order = this.orders.find(o => o.id === orderId);
        if (order) {
            order.status = newStatus;
            this.saveOrders();
            this.updateOrdersDisplay();
            this.closeAllModals();
            this.showNotification(`Buyurtma holati yangilandi: ${this.getStatusText(newStatus)}`, 'success');
            
            // Send Telegram notification if enabled
            if (this.settings.enable_telegram_notifications) {
                this.sendTelegramNotification(order, newStatus);
            }
        }
    }

    // ========================
    // PRODUCTS MANAGEMENT
    // ========================
    updateProductsDisplay() {
        this.updateProductsGrid();
        this.updateProductsCount();
    }

    updateProductsGrid() {
        const grid = document.querySelector('.products-grid-admin');
        if (!grid) return;
        
        grid.innerHTML = this.products.map(product => `
            <div class="product-card-admin">
                <div class="product-image-admin">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                    <div class="product-badge-admin">
                        <span class="badge-rating">⭐ ${product.rating}</span>
                        <span class="badge-time">⏱ ${product.preparation_time}min</span>
                        <span class="badge-category">${product.category}</span>
                    </div>
                </div>
                <div class="product-info-admin">
                    <h3>${product.name}</h3>
                    <p class="product-description">${product.description}</p>
                    <div class="product-price-admin">${this.formatPrice(product.price)}</div>
                    <div class="product-actions">
                        <button class="btn btn-primary" onclick="admin.editProduct(${product.id})">
                            <i class="fas fa-edit"></i> Tahrirlash
                        </button>
                        <button class="btn btn-danger" onclick="admin.deleteProduct(${product.id})">
                            <i class="fas fa-trash"></i> O'chirish
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    showProductModal(productId = null) {
        const isEdit = productId !== null;
        const product = isEdit ? this.products.find(p => p.id === productId) : null;
        
        document.getElementById('productModalTitle').textContent = 
            isEdit ? 'Mahsulotni Tahrirlash' : 'Yangi Mahsulot Qo\'shish';
        
        const form = document.getElementById('productForm');
        form.innerHTML = `
            <div class="form-group">
                <label for="productName">Mahsulot Nomi</label>
                <input type="text" id="productName" value="${product ? product.name : ''}" required>
            </div>
            
            <div class="form-group">
                <label for="productCategory">Kategoriya</label>
                <select id="productCategory" required>
                    <option value="uzbek" ${product && product.category === 'uzbek' ? 'selected' : ''}>O'zbek Taomlari</option>
                    <option value="japanese" ${product && product.category === 'japanese' ? 'selected' : ''}>Yapon Taomlari</option>
                    <option value="drinks" ${product && product.category === 'drinks' ? 'selected' : ''}>Ichimliklar</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="productPrice">Narx (so'm)</label>
                <input type="number" id="productPrice" value="${product ? product.price : ''}" required>
            </div>
            
            <div class="form-group">
                <label for="productDescription">Tavsif</label>
                <textarea id="productDescription" rows="3" required>${product ? product.description : ''}</textarea>
            </div>
            
            <div class="form-group">
                <label for="productImage">Rasm URL</label>
                <input type="url" id="productImage" value="${product ? product.image : ''}" required>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="productRating">Reyting</label>
                    <input type="number" id="productRating" step="0.1" min="0" max="5" value="${product ? product.rating : '4.5'}">
                </div>
                
                <div class="form-group">
                    <label for="productPrepTime">Tayyorlash Vaqti (min)</label>
                    <input type="number" id="productPrepTime" value="${product ? product.preparation_time : '20'}">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    ${isEdit ? 'Saqlash' : 'Qo\'shish'}
                </button>
                <button type="button" class="btn btn-secondary" onclick="admin.closeAllModals()">
                    Bekor qilish
                </button>
            </div>
        `;
        
        form.onsubmit = (e) => {
            e.preventDefault();
            this.saveProduct(productId);
        };
        
        this.showModal('productModal');
    }

    saveProduct(productId) {
        const formData = {
            name: document.getElementById('productName').value,
            category: document.getElementById('productCategory').value,
            price: parseInt(document.getElementById('productPrice').value),
            description: document.getElementById('productDescription').value,
            image: document.getElementById('productImage').value,
            rating: parseFloat(document.getElementById('productRating').value),
            preparation_time: parseInt(document.getElementById('productPrepTime').value)
        };
        
        if (productId) {
            // Edit existing product
            const index = this.products.findIndex(p => p.id === productId);
            if (index !== -1) {
                this.products[index] = { ...this.products[index], ...formData };
            }
        } else {
            // Add new product
            const newId = Math.max(...this.products.map(p => p.id), 0) + 1;
            this.products.push({
                id: newId,
                ...formData,
                is_available: true
            });
        }
        
        this.saveProducts();
        this.updateProductsDisplay();
        this.closeAllModals();
        this.showNotification(`Mahsulot ${productId ? 'tahrirlandi' : 'qo\'shildi'}!`, 'success');
    }

    // ========================
    // CUSTOMERS MANAGEMENT
    // ========================
    updateCustomersDisplay() {
        this.updateCustomersStats();
        this.updateCustomersTable();
    }

    updateCustomersStats() {
        document.getElementById('totalCustomers').textContent = this.customers.length;
        document.getElementById('activeCustomers').textContent = this.customers.filter(c => 
            new Date(c.last_order) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
        ).length;
        document.getElementById('newCustomersToday').textContent = this.customers.filter(c =>
            new Date(c.first_order).toDateString() === new Date().toDateString()
        ).length;
    }

    updateCustomersTable() {
        const tbody = document.getElementById('customersTableBody');
        
        tbody.innerHTML = this.customers.map(customer => `
            <tr>
                <td>
                    <div><strong>${customer.name}</strong></div>
                    <small>${customer.address}</small>
                </td>
                <td>${customer.phone}</td>
                <td>${customer.order_count} ta</td>
                <td>${this.formatPrice(customer.total_spent)}</td>
                <td>${this.formatTimeAgo(customer.last_order)}</td>
                <td>
                    <span class="status-badge ${customer.order_count > 1 ? 'status-completed' : 'status-pending'}">
                        ${customer.order_count > 1 ? 'Sodiq' : 'Yangi'}
                    </span>
                </td>
            </tr>
        `).join('');
    }

    // ========================
    // CHARTS AND ANALYTICS
    // ========================
    initCharts() {
        this.initRevenueChart();
        this.initProductsChart();
        this.initSalesTrendChart();
    }

    initRevenueChart() {
        const ctx = document.getElementById('revenueChart').getContext('2d');
        this.charts.revenue = new Chart(ctx, {
            type: 'line',
            data: {
                labels: this.getLast7Days(),
                datasets: [{
                    label: 'Daromad (so\'m)',
                    data: this.generateRevenueData(),
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }

    initProductsChart() {
        const ctx = document.getElementById('productsChart').getContext('2d');
        this.charts.products = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Osh', 'Sushi', 'Ramen', 'Qazi', 'Boshqalar'],
                datasets: [{
                    data: [35, 25, 20, 15, 5],
                    backgroundColor: [
                        '#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    updateAnalyticsCharts() {
        // Update charts with latest data
        if (this.charts.revenue) {
            this.charts.revenue.data.labels = this.getLast7Days();
            this.charts.revenue.data.datasets[0].data = this.generateRevenueData();
            this.charts.revenue.update();
        }
    }

    getLast7Days() {
        const days = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            days.push(date.toLocaleDateString('uz-UZ', { weekday: 'short' }));
        }
        return days;
    }

    generateRevenueData() {
        return Array.from({length: 7}, () => Math.floor(Math.random() * 1000000) + 500000);
    }

    // ========================
    // SETTINGS MANAGEMENT
    // ========================
    updateSettingsForm() {
        document.getElementById('restaurantName').value = this.settings.restaurant_name;
        document.getElementById('restaurantPhone').value = this.settings.restaurant_phone;
        document.getElementById('deliveryTime').value = this.settings.delivery_time;
        document.getElementById('minOrderAmount').value = this.settings.min_order_amount;
        document.getElementById('telegramBotToken').value = this.settings.telegram_bot_token;
        document.getElementById('telegramChatId').value = this.settings.telegram_chat_id;
        document.getElementById('enableTelegramNotifications').checked = this.settings.enable_telegram_notifications;
        document.getElementById('enable2FA').checked = this.settings.enable_2fa;
    }

    saveSettingsFromForm() {
        this.settings = {
            restaurant_name: document.getElementById('restaurantName').value,
            restaurant_phone: document.getElementById('restaurantPhone').value,
            delivery_time: parseInt(document.getElementById('deliveryTime').value),
            min_order_amount: parseInt(document.getElementById('minOrderAmount').value),
            telegram_bot_token: document.getElementById('telegramBotToken').value,
            telegram_chat_id: document.getElementById('telegramChatId').value,
            enable_telegram_notifications: document.getElementById('enableTelegramNotifications').checked,
            enable_2fa: document.getElementById('enable2FA').checked,
            currency: 'so\'m',
            timezone: 'Asia/Tashkent'
        };
        
        this.saveSettings();
        this.showNotification('Sozlamalar saqlandi!', 'success');
    }

    resetSettings() {
        if (confirm('Hamma sozlamalarni standart holatiga qaytarishni xohlaysizmi?')) {
            this.settings = this.getDefaultSettings();
            this.saveSettings();
            this.updateSettingsForm();
            this.showNotification('Sozlamalar qaytarildi!', 'success');
        }
    }

    // ========================
    // DATA EXPORT/IMPORT
    // ========================
    exportOrdersToCSV() {
        const headers = ['ID', 'Mijoz', 'Telefon', 'Mahsulotlar', 'Summa', 'Holat', 'Sana'];
        const csvData = this.orders.map(order => [
            order.id,
            order.customer.name,
            order.customer.phone,
            order.items.map(item => `${item.name}×${item.quantity}`).join(';'),
            order.total,
            this.getStatusText(order.status),
            this.formatDateTime(order.timestamp)
        ]);
        
        this.downloadCSV([headers, ...csvData], 'fooduzjpn_orders.csv');
        this.showNotification('Buyurtmalar CSV fayliga yuklab olindi', 'success');
    }

    exportAllData() {
        const data = {
            orders: this.orders,
            products: this.products,
            customers: this.customers,
            settings: this.settings,
            export_date: new Date().toISOString()
        };
        
        this.download 
            exportAllData() {
        const data = {
            orders: this.orders,
            products: this.products,
            customers: this.customers,
            settings: this.settings,
            export_date: new Date().toISOString()
        };
        
        this.downloadJSON(data, 'fooduzjpn_backup.json');
        this.showNotification('Barcha ma\'lumotlar yuklab olindi', 'success');
    }

    importData() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        
        input.onchange = (e) => {
            const file = e.target.files[0];
            const reader = new FileReader();
            
            reader.onload = (event) => {
                try {
                    const data = JSON.parse(event.target.result);
                    
                    if (confirm('Hozirgi ma\'lumotlar o\'chirilib, yangilari yuklanadi. Davom etishni xohlaysizmi?')) {
                        if (data.orders) {
                            localStorage.setItem('fooduzjpn_orders', JSON.stringify(data.orders));
                            this.orders = data.orders;
                        }
                        if (data.products) {
                            localStorage.setItem('fooduzjpn_products', JSON.stringify(data.products));
                            this.products = data.products;
                        }
                        if (data.settings) {
                            localStorage.setItem('fooduzjpn_admin_settings', JSON.stringify(data.settings));
                            this.settings = data.settings;
                        }
                        
                        this.loadCustomers(); // Reload customers from updated orders
                        this.updateAllDisplays();
                        this.showNotification('Ma\'lumotlar muvaffaqiyatli yuklandi!', 'success');
                    }
                } catch (error) {
                    this.showNotification('Faylni o\'qishda xatolik!', 'error');
                }
            };
            
            reader.readAsText(file);
        };
        
        input.click();
    }

    clearAllData() {
        if (confirm('Hamma ma\'lumotlar o\'chiriladi. Bu amalni ortga qaytarib bo\'lmaydi. Davom etishni xohlaysizmi?')) {
            localStorage.removeItem('fooduzjpn_orders');
            localStorage.removeItem('fooduzjpn_products');
            localStorage.removeItem('fooduzjpn_admin_settings');
            
            this.orders = [];
            this.products = [];
            this.customers = [];
            this.settings = this.getDefaultSettings();
            
            this.saveSettings();
            this.updateAllDisplays();
            this.showNotification('Barcha ma\'lumotlar tozalandi', 'info');
        }
    }

    downloadCSV(data, filename) {
        const csvContent = data.map(row => 
            row.map(field => `"${String(field).replace(/"/g, '""')}"`).join(',')
        ).join('\n');
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        this.downloadBlob(blob, filename);
    }

    downloadJSON(data, filename) {
        const jsonContent = JSON.stringify(data, null, 2);
        const blob = new Blob([jsonContent], { type: 'application/json' });
        this.downloadBlob(blob, filename);
    }

    downloadBlob(blob, filename) {
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    // ========================
    // UTILITY FUNCTIONS
    // ========================
    formatPrice(price) {
        return new Intl.NumberFormat('uz-UZ').format(price) + ' so\'m';
    }

    formatDateTime(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('uz-UZ') + ' ' + date.toLocaleTimeString('uz-UZ', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    formatTimeAgo(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);
        
        if (diffMins < 1) return 'Hozirgina';
        if (diffMins < 60) return `${diffMins} min oldin`;
        if (diffHours < 24) return `${diffHours} soat oldin`;
        if (diffDays < 7) return `${diffDays} kun oldin`;
        
        return this.formatDateTime(dateString);
    }

    getStatusText(status) {
        const statusTexts = {
            'pending': 'Kutilmoqda',
            'preparing': 'Tayyorlanmoqda',
            'delivering': 'Yetkazilmoqda',
            'completed': 'Yakunlangan',
            'cancelled': 'Bekor qilingan'
        };
        return statusTexts[status] || status;
    }

    updateCurrentDate() {
        const now = new Date();
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            timeZone: 'Asia/Tashkent'
        };
        document.getElementById('currentDate').textContent = 
            now.toLocaleDateString('uz-UZ', options);
    }

    updateRealTimeStats() {
        // Update time every minute
        setInterval(() => {
            this.updateCurrentDate();
        }, 60000);
        
        // Update stats every 5 minutes
        setInterval(() => {
            this.updateStatsCards();
        }, 300000);
    }

    startRealTimeUpdates() {
        // Simulate real-time order updates
        setInterval(() => {
            if (Math.random() < 0.3) { // 30% chance of new order
                this.simulateNewOrder();
            }
        }, 30000); // Every 30 seconds
    }

    simulateNewOrder() {
        const products = this.products.filter(p => p.is_available);
        if (products.length === 0) return;
        
        const itemCount = Math.floor(Math.random() * 2) + 1;
        const orderItems = [];
        let total = 0;
        
        for (let i = 0; i < itemCount; i++) {
            const product = products[Math.floor(Math.random() * products.length)];
            const quantity = Math.floor(Math.random() * 2) + 1;
            orderItems.push({
                id: product.id,
                name: product.name,
                price: product.price,
                quantity: quantity
            });
            total += product.price * quantity;
        }
        
        const newOrder = {
            id: 'ORD_' + (1000 + this.orders.length + 1),
            customer: {
                name: this.generateRandomName(),
                phone: '+9989' + Math.floor(Math.random() * 100000000).toString().padStart(8, '0'),
                address: this.generateRandomAddress()
            },
            items: orderItems,
            total: total,
            status: 'pending',
            timestamp: new Date().toISOString(),
            estimated_delivery: new Date(Date.now() + 30 * 60000).toISOString()
        };
        
        this.orders.unshift(newOrder);
        this.saveOrders();
        
        // Update displays if on relevant tabs
        if (this.currentTab === 'dashboard' || this.currentTab === 'orders') {
            this.updateOrdersDisplay();
            this.updateStatsCards();
            this.updateRecentActivity();
        }
        
        // Show notification
        this.showNotification(`Yangi buyurtma: ${newOrder.id}`, 'info');
        
        // Send Telegram notification if enabled
        if (this.settings.enable_telegram_notifications) {
            this.sendTelegramNotification(newOrder, 'pending');
        }
    }

    sendTelegramNotification(order, status) {
        if (!this.settings.telegram_bot_token || !this.settings.telegram_chat_id) {
            return;
        }
        
        const message = `🛒 *Yangi Buyurtma*\\n\\n` +
                       `📦 *ID:* ${order.id}\\n` +
                       `👤 *Mijoz:* ${order.customer.name}\\n` +
                       `📞 *Telefon:* ${order.customer.phone}\\n` +
                       `📍 *Manzil:* ${order.customer.address}\\n` +
                       `💵 *Summa:* ${this.formatPrice(order.total)}\\n` +
                       `📋 *Holat:* ${this.getStatusText(status)}\\n` +
                       `⏰ *Vaqt:* ${this.formatDateTime(order.timestamp)}`;
        
        // In a real implementation, this would send to Telegram API
        console.log('Telegram notification:', message);
    }

    // ========================
    // UI/UX FUNCTIONS
    // ========================
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span class="notification-icon">
                    ${type === 'success' ? '✅' : 
                      type === 'error' ? '❌' : 
                      type === 'warning' ? '⚠️' : 'ℹ️'}
                </span>
                <span class="notification-message">${message}</span>
            </div>
            <button class="notification-close" onclick="this.parentElement.remove()">
                ×
            </button>
        `;
        
        document.getElementById('notificationsContainer').appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    showModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
        document.body.style.overflow = 'hidden';
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
        document.body.style.overflow = 'auto';
    }

    showLoading() {
        document.getElementById('loadingScreen').style.display = 'flex';
    }

    hideLoading() {
        document.getElementById('loadingScreen').style.display = 'none';
    }

    toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
                console.log('Fullscreen error:', err);
            });
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    }

    refreshData() {
        this.showLoading();
        setTimeout(async () => {
            await this.loadData();
            this.updateAllDisplays();
            this.hideLoading();
            this.showNotification('Ma\'lumotlar yangilandi', 'success');
        }, 1000);
    }

    updateAllDisplays() {
        this.updateDashboard();
        this.updateOrdersDisplay();
        this.updateProductsDisplay();
        this.updateCustomersDisplay();
        this.updateAnalyticsCharts();
    }

    initPagination() {
        // Simple pagination implementation
        // This would be expanded for larger datasets
        console.log('Pagination initialized');
    }

    printOrder(orderId) {
        const order = this.orders.find(o => o.id === orderId);
        if (!order) return;
        
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Buyurtma ${order.id}</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        .header { text-align: center; margin-bottom: 20px; }
                        .section { margin-bottom: 15px; }
                        .items { width: 100%; border-collapse: collapse; }
                        .items td, .items th { border: 1px solid #ddd; padding: 8px; }
                        .total { font-weight: bold; font-size: 1.2em; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        <h1>FoodUzJpn</h1>
                        <h2>Buyurtma Kvitansiyasi</h2>
                    </div>
                    
                    <div class="section">
                        <strong>Buyurtma ID:</strong> ${order.id}<br>
                        <strong>Sana:</strong> ${this.formatDateTime(order.timestamp)}
                    </div>
                    
                    <div class="section">
                        <strong>Mijoz:</strong> ${order.customer.name}<br>
                        <strong>Telefon:</strong> ${order.customer.phone}<br>
                        <strong>Manzil:</strong> ${order.customer.address}
                    </div>
                    
                    <table class="items">
                        <tr>
                            <th>Mahsulot</th>
                            <th>Miqdor</th>
                            <th>Narx</th>
                            <th>Jami</th>
                        </tr>
                        ${order.items.map(item => `
                            <tr>
                                <td>${item.name}</td>
                                <td>${item.quantity}</td>
                                <td>${this.formatPrice(item.price)}</td>
                                <td>${this.formatPrice(item.price * item.quantity)}</td>
                            </tr>
                        `).join('')}
                        <tr class="total">
                            <td colspan="3" style="text-align: right;">Umumiy summa:</td>
                            <td>${this.formatPrice(order.total)}</td>
                        </tr>
                    </table>
                    
                    <div class="section">
                        <strong>Yetkazish vaqti:</strong> ${this.formatDateTime(order.estimated_delivery)}<br>
                        <strong>Holat:</strong> ${this.getStatusText(order.status)}
                    </div>
                    
                    <script>
                        window.onload = function() {
                            window.print();
                            setTimeout(function() {
                                window.close();
                            }, 1000);
                        }
                    </script>
                </body>
            </html>
        `);
        printWindow.document.close();
    }

    deleteOrder(orderId) {
        if (confirm('Bu buyurtmani o\'chirishni xohlaysizmi?')) {
            this.orders = this.orders.filter(order => order.id !== orderId);
            this.saveOrders();
            this.updateOrdersDisplay();
            this.showNotification('Buyurtma o\'chirildi', 'success');
        }
    }

    deleteProduct(productId) {
        if (confirm('Bu mahsulotni o\'chirishni xohlaysizmi?')) {
            this.products = this.products.filter(product => product.id !== productId);
            this.saveProducts();
            this.updateProductsDisplay();
            this.showNotification('Mahsulot o\'chirildi', 'success');
        }
    }

    editProduct(productId) {
        this.showProductModal(productId);
    }

    editOrderStatus(orderId) {
        const order = this.orders.find(o => o.id === orderId);
        if (!order) return;
        
        const modalContent = document.getElementById('orderStatusContent');
        modalContent.innerHTML = `
            <div class="status-edit">
                <h4>Buyurtma holatini o'zgartirish</h4>
                <p><strong>Buyurtma:</strong> ${order.id}</p>
                <p><strong>Mijoz:</strong> ${order.customer.name}</p>
                
                <div class="status-options">
                    ${['pending', 'preparing', 'delivering', 'completed', 'cancelled'].map(status => `
                        <label class="status-option">
                            <input type="radio" name="orderStatus" value="${status}" 
                                   ${order.status === status ? 'checked' : ''}>
                            <span class="status-badge status-${status}">
                                ${this.getStatusText(status)}
                            </span>
                        </label>
                    `).join('')}
                </div>
                
                <div class="form-actions">
                    <button class="btn btn-primary" onclick="admin.saveOrderStatus('${orderId}')">
                        Saqlash
                    </button>
                    <button class="btn btn-secondary" onclick="admin.closeAllModals()">
                        Bekor qilish
                    </button>
                </div>
            </div>
        `;
        
        this.showModal('orderStatusModal');
    }

    saveOrderStatus(orderId) {
        const selectedStatus = document.querySelector('input[name="orderStatus"]:checked');
        if (selectedStatus) {
            this.changeOrderStatus(orderId, selectedStatus.value);
        }
    }
}

// ========================
// INITIALIZATION
// ========================

// Global admin instance
let admin;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    admin = new FoodUzJpnAdmin();
});

// Make admin available globally for HTML onclick handlers
window.admin = admin;

// Service Worker for offline functionality (basic implementation)
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').then(() => {
        console.log('Service Worker registered');
    }).catch(error => {
        console.log('Service Worker registration failed:', error);
    });
}